#include <iostream>
#include <fstream>
#include <cstdint>
#include <algorithm>

template <class T>
void endswap(T* objp)
{
	unsigned char* memp = reinterpret_cast<unsigned char*>(objp);
	std::reverse(memp, memp + sizeof(T));
}

using namespace std;

typedef unsigned char UINT8;
typedef unsigned short UINT16;
typedef unsigned int UINT32;



UINT16 rotate_left(UINT16 value, int n)
{
	int aux = value >> (16 - n);
	return ((value << n) | aux) % 0x10000;
}

UINT16 rotxor(UINT16 val, UINT16 xorval)
{
	UINT16 res = val + rotate_left(val, 2);
	res = rotate_left(res, 4) ^ (res & (val ^ xorval));
	return res;
}

UINT32 cps3_mask(UINT32 address, UINT32 key1, UINT32 key2)
{
	address ^= key1;
	UINT16 val = (address & 0xffff) ^ 0xffff;
	val = rotxor(val, key2 & 0xffff);
	val ^= (address >> 16) ^ 0xffff;
	val = rotxor(val, key2 >> 16);
	val ^= (address & 0xffff) ^ (key2 & 0xffff);
	return val | (val << 16);
}
bool allFilesOpened(ifstream& file1, ifstream& file2, ifstream& file3, ifstream& file4, ifstream& file5)
{
	return (file1.is_open() && file2.is_open() && file3.is_open() && file4.is_open() && file5.is_open());
}
int main()
{
	bool simmProcessing = false;
	bool twentyFile = false;
	UINT32 dataOffset = (twentyFile) ? 0x06800000 : 0x06000000;
	printf("\n\n DataOffset set to 0x%08X\n\n", dataOffset);

	const char* file_ten = "custom_10_file"; // Input 10 File
	ifstream file_10(file_ten, ios::in | ios::binary);
	
	const char* simm1_0 = "sfiii3n-simm1.0"; // Input SIMM 1.0
	ifstream simm1_0_file(simm1_0, ios::in | ios::binary);
	const char* simm1_1 = "sfiii3n-simm1.1"; // Input SIMM 1.1
	ifstream simm1_1_file(simm1_1, ios::in | ios::binary);
	const char* simm1_2 = "sfiii3n-simm1.2"; // Input SIMM 1.2
	ifstream simm1_2_file(simm1_2, ios::in | ios::binary);
	const char* simm1_3 = "sfiii3n-simm1.3"; // Input SIMM 1.3
	ifstream simm1_3_file(simm1_3, ios::in | ios::binary);

	const char* outFileName = "dec_10_sfiii3nr1_2020_10_28"; // Output 10 File
	ofstream decryptedFile(outFileName, ios::out | ios::binary);

	const char* o_simm1_0 = "sfiii3ex-simm1.0"; // Output SIMM 1.0
	ofstream o_simm1_0_file(o_simm1_0, ios::out | ios::binary);
	const char* o_simm1_1 = "sfiii3ex-simm1.1"; // Output SIMM 1.1
	ofstream o_simm1_1_file(o_simm1_1, ios::out | ios::binary);
	const char* o_simm1_2 = "sfiii3ex-simm1.2"; // Output SIMM 1.2
	ofstream o_simm1_2_file(o_simm1_2, ios::out | ios::binary);
	const char* o_simm1_3 = "sfiii3ex-simm1.3"; // Output SIMM 1.3
	ofstream o_simm1_3_file(o_simm1_3, ios::out | ios::binary);


	if (allFilesOpened(simm1_0_file, simm1_1_file, simm1_2_file, simm1_3_file, file_10))
	{
		
		UINT32 curData = 0, newData = 0;
		UINT32 simmFilesize = 0x00200000;
	
		file_10.seekg(0, ios::beg);
		simm1_0_file.seekg(0, ios::beg);
		simm1_1_file.seekg(0, ios::beg);
		simm1_2_file.seekg(0, ios::beg);
		simm1_3_file.seekg(0, ios::beg);


		char* buffer = new char;
		for (UINT32 i = 0; i < simmFilesize; i++)
		{ 
			curData = 0, newData = 0; // Reset data
			if (simmProcessing)
			{
				simm1_0_file.read(buffer, sizeof(UINT8));
				curData = (curData | *buffer & 0xFF) << 8; // Ensure only a byte is used, added, and then shifted.

				simm1_1_file.read(buffer, sizeof(UINT8));
				curData = (curData | *buffer & 0xFF) << 8;

				simm1_2_file.read(buffer, sizeof(UINT8));
				curData = (curData | *buffer & 0xFF) << 8;

				simm1_3_file.read(buffer, sizeof(UINT8));
				curData = (curData | *buffer & 0xFF);
				//printf("curData: 0x%08X\n", curData);
			}
			else
			{
				file_10.read((char*)&curData, sizeof(UINT32));
				endswap(&curData);
				//printf("curData: 0x%08X\n", curData);
			}
			
			newData = curData ^ (cps3_mask(dataOffset + (i * 4), 0xA55432B4, 0x0C129981));
			//printf("newData: 0x%08X\n", newData);
			endswap(&newData);
			
			o_simm1_0_file.write((char*)&newData, sizeof(UINT8));
			o_simm1_1_file.write((char*)&newData + 1, sizeof(UINT8));
			o_simm1_2_file.write((char*)&newData + 2, sizeof(UINT8));
			o_simm1_3_file.write((char*)&newData + 3, sizeof(UINT8));

			decryptedFile.write((char*)&newData, sizeof(UINT32));
			
		}
		delete buffer;

	}
	else
	{
		printf("\n\n\n\tFILES NOT OPENED SUCCESSFULLY.\n\n\n");
	}
	file_10.close();
	simm1_0_file.close();
	simm1_1_file.close();
	simm1_2_file.close();
	simm1_3_file.close();

	decryptedFile.close();
	o_simm1_0_file.close();
	o_simm1_1_file.close();
	o_simm1_2_file.close();
	o_simm1_3_file.close();
	return 0;
}